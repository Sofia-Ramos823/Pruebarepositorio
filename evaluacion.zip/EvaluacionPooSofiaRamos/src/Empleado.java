public class Empleado extends Persona {
    private String departamento;
    private float salario;
    private String fechaContratacion;

    public Empleado(String nombre, String direccion, String telefono, String correoElectronico, String departamento, double salario, String fechaContratacion) {
        super(nombre, direccion, telefono, correoElectronico);
        setDepartamento(departamento);
        this.salario = (float) salario;
        this.fechaContratacion = fechaContratacion;
    }

    public void setDepartamento(String departamento) {
        String[] departamentosValidos = {"Contabilidad", "Recursos Humanos", "Compras"};
        boolean departamentoValido = false;
        for (String depato : departamentosValidos) {
            if (depato.equals(departamento)) {
                departamentoValido = true;
                break;
            }
        }
        if (departamentoValido) {
            this.departamento = departamento;
        } else {
            this.departamento = "Recursos Humanos";
        }
    }

    @Override
    public String toString() {
        return super.toString() + ", Departamento: " + departamento + ", Salario: " + salario + ", Fecha de Contratación: " + fechaContratacion;
    }
}