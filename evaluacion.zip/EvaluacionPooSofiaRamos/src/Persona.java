public class Persona {
    private String nombre;
    private String direccion;
    private String telefono;
    private String correoElectronico;

    public Persona(String nombre, String direccion, String telefono, String correoElectronico) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
        this.correoElectronico = correoElectronico;
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + ", Dirección: " + direccion + ", Teléfono: " + telefono + ", Correo Electrónico: " + correoElectronico ;
    }
}